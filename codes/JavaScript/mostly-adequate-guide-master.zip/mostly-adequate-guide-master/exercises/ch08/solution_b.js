const initial = compose(map(head), safeProp('name'));
