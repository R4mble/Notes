const eitherWelcome = compose(map(showWelcome), checkActive);
