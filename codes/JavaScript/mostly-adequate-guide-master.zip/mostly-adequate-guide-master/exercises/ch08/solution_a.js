const incrF = map(add(1));
