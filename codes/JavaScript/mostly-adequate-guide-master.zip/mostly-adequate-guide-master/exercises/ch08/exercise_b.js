// Given the following User object:
//
//   const user = { id: 2, name: 'Albert', active: true };
//
// Use `safeProp` and `head` to find the first initial of the user.

// initial :: User -> Maybe String
const initial = undefined;
