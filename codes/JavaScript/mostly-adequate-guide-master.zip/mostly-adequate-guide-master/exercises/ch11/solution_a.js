const eitherToMaybe = either(always(nothing), Maybe.of);
