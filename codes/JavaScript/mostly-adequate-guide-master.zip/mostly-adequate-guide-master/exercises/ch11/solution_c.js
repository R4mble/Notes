const strToList = split('');

const listToStr = intercalate('');
