const max = reduce(keepHighest, -Infinity);
