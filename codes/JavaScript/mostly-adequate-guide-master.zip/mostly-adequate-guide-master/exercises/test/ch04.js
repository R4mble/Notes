const { describe } = require('mocha');
const { runExercises } = require('../test-utils');

describe('Exercises Chapter 04', () => {
  runExercises('ch04');
});
