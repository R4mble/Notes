const { describe } = require('mocha');
const { runExercises } = require('../test-utils');

describe('Exercises Chapter 05', () => {
  runExercises('ch05');
});
