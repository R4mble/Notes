const { describe } = require('mocha');
const { runSolutions } = require('../test-utils');

describe('Exercises Chapter 04', () => {
  runSolutions('ch04');
});
