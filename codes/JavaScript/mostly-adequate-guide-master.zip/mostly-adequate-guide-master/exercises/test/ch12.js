const { describe } = require('mocha');
const { runExercises } = require('../test-utils');

describe('Exercises Chapter 12', () => {
  runExercises('ch12');
});

