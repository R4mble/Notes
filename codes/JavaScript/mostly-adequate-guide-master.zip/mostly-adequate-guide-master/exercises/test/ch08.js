const { describe } = require('mocha');
const { runExercises } = require('../test-utils');

describe('Exercises Chapter 08', () => {
  runExercises('ch08');
});
