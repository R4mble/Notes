const { describe } = require('mocha');
const { runSolutions } = require('../test-utils');

describe('Exercises Chapter 10', () => {
  runSolutions('ch10');
});

