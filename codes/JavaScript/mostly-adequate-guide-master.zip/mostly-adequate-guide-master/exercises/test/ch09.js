const { describe } = require('mocha');
const { runExercises } = require('../test-utils');

describe('Exercises Chapter 09', () => {
  runExercises('ch09');
});
