const isLastInStock = compose(prop('in_stock'), last);
