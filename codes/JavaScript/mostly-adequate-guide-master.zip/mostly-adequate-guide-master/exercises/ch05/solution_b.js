const averageDollarValue = compose(average, map(prop('dollar_value')));
