// Rewrite `safeAdd` from exercise_a to use `liftA2` instead of `ap`.

// safeAdd :: Maybe Number -> Maybe Number -> Maybe Number
const safeAdd = undefined;
