# 2.0.1 - 2019-06-26

- Fix `Maybe.sequence` missing a `return` statement

# 2.0.0 - 2019-05-24

- Change `nothing :: () -> Maybe a` to `nothing :: Maybe a`

# 1.2.0 - 2019-05-05

- Fix `inspect` deprecation warning on node.js
